var searchvideoApp = angular.module('searchvideoApp', []);
searchvideoApp.controller('searchvideoController', ['$scope', '$http', 'dataService', function($scope, $http, dataService) {
    console.log('Ready for search video');

    $scope.searchvideo = 'search Video engine';


    /*------- API call to get the searcj json data   -------*/
    $scope.data = null;
    dataService.getData().then(function(dataResponse) {
        $scope.data = dataResponse;
        for (var i = 0; i < $scope.data.data.page["content-items"]["content"].length; i++) {
        console.log($scope.data.data.page["content-items"]["content"][i]);
        $scope.datajson = $scope.data.data.page["content-items"]["content"][i];
    }
    });




}]);

/*-------using services getting json data-------------*/

searchvideoApp.service('dataService', function($http) {
    this.getData = function() {
        return $http({
            method: 'GET',
            url: '../API/CONTENTLISTINGPAGE-PAGE1.json',
            headers: { 'Authorization': 'Token token=xxxxYYYYZzzz' }
        });
    }
});